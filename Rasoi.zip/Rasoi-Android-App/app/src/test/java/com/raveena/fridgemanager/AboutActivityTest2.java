package com.raveena.fridgemanager;

public class AboutActivityTest2 {



    }

