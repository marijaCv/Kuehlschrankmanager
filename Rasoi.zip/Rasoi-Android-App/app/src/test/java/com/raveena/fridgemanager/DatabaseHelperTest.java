package com.raveena.fridgemanager;

import org.junit.Test;

public class DatabaseHelperTest {
    @Test
    public void databaseHelperTest() {
//    DatabaseHelper dbh = new DatabaseHelper();

    }

}