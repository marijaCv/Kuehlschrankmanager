package com.raveena.fridgemanager;

import org.junit.Assert;
import org.junit.Test;

import java.util.List;

public class  StatisticsActivityTest {
@Test
    public void displayFrozenStatsTest(){
    StatisticsActivity sa = new StatisticsActivity();
    FoodModel fm = new FoodModel(1, "Paprika", "Vegetables", "Lidl", true);
    Assert.assertEquals(true, sa.displayFrozenStats((List<FoodModel>) fm));
}
}