package com.raveena.fridgemanager;

public class AboutActivityTest3 {
 /** @Rule
    public ActivityTestRule<AboutActivity> aboutActivityTestRule = new ActivityTestRule<AboutActivity>(AboutActivity.class);
    private AboutActivity aboutActivity = null;
    Instrumentation.ActivityMonitor monitor = getInstrumentation().addMonitor(ContactActivity.class.getName(),null,false);
    @Before
    public void setUp() throws Exception {

        aboutActivity = aboutActivityTestRule.getActivity();
    }

    @Test
    public void testLaunchOfContactActivityOnButtonClick(){
        assertNotNull(aboutActivity.findViewById(R.id.contact_btn));

        onView(withId(R.id.contact_btn)).perform(click());

        Activity contactActivity = getInstrumentation().waitForMonitorTimeout(monitor, 5000);

        assertNotNull(contactActivity);

        contactActivity.finish();
    }

    @After
    public void tearDown() throws Exception {

        aboutActivity = null;
    }
  **/
}