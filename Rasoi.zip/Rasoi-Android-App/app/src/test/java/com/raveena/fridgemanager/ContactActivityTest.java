package com.raveena.fridgemanager;

import org.junit.Test;

import static org.junit.Assert.assertTrue;


public class ContactActivityTest {
    @Test
    public void emailValidator() {
     //   ContactActivity ca = new ContactActivity();
     //   CharSequence email = "name@gmail.com";
        assertTrue(ContactActivity.isEmailValid("name@gmail.com"));

    }


}