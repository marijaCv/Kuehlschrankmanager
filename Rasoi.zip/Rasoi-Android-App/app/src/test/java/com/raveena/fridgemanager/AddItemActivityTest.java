package com.raveena.fridgemanager;

import org.junit.Test;

import static org.junit.Assert.assertEquals;

public class AddItemActivityTest {
@Test
    public void onOptionsItemSelectedTest(){
    AddItemActivity aia = new AddItemActivity();
   /* ArrayList<String> cat = new ArrayList<>();
    cat.add("Pick a category");
    cat.add("Fruits");
    cat.add("Vegetables");
    cat.add("Dairy");
    cat.add("Grains");
    cat.add("Meat &/Or Eggs");
    cat.add("Fish");
    cat.add("Other");*/
    assertEquals(0, aia.getCategoryNames().size());

}

}