package com.raveena.fridgemanager;
import org.junit.Test;

import static org.junit.Assert.assertEquals;
public class EditFoodItemTest {

    @Test
    public void assignExpiryTime(){
        EditFoodItem efi = new EditFoodItem();
        int frozenStatus = efi.assignExpiryTime("Fruits", false);
        assertEquals(14, frozenStatus);
        int frozenStatus2 = efi.assignExpiryTime("Fish", true);
        assertEquals(30,frozenStatus2);

    }
    @Test
    public void addCategoryNamesTest(){
       // EditFoodItem efi = new EditFoodItem();
       /* ArrayList<String> cats = efi.addCategoryNames(Collections.singletonList("Zwiebel"));
        List<String> categories = null;
        categories.add("Fruits");
        categories.add("Vegetables");
        categories.add("Dairy");
        /*categories.add("Grains");
        categories.add("Meat &/Or Eggs");
        categories.add("Fish");
        categories.add("Other");
        assertEquals(Arrays.asList("Fruits", "Vegetables", "Dairy"), categories);*/
    }


}