package com.raveena.fridgemanager;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

class dipIsFrozen extends SQLiteOpenHelper {

    public dipIsFrozen(@Nullable Context context, @Nullable String name, @Nullable SQLiteDatabase.CursorFactory factory, int version) {
        super(context, name, factory, version);
    }

   /* public boolean getFrozenStatus(int ID) {
        String query = "SELECT " +  COLUMN_FROZEN + " FROM " + TABLE_NAME + " WHERE " + COLUMN_ID + " = " + ID;
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery(query, null);
        boolean result = false;
        if (cursor.moveToFirst()) {
            System.out.println(cursor.getString(0));
            if (cursor.getString(0).equalsIgnoreCase("1")) {
                result = true;
            }
        }
        cursor.close();
        db.close();
        return result;
    }
*/
    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {

    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {

    }
}
