package com.raveena.fridgemanager;

class dipFrozenStatus {
 /*  private dipIsFrozen isFrozen;
   public dipFrozenStatus(dipIsFrozen isFrozen){
      this.isFrozen = isFrozen;
   }
   public void doSmth(){
      isFrozen
   }*/
}
