package com.raveena.fridgemanager;

import android.os.Bundle;

abstract class decoratorClass implements intrfs{
   protected intrfs tempIntrfs;
   public decoratorClass(intrfs newIntrfs){
      tempIntrfs = newIntrfs;
   }
   public void onCreate(Bundle savedInstanceState){

   }
}
