package com.raveena.fridgemanager;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;
// SOLID bzw. Single Responsability Principle: this class is made from MainActivity.class bzw. the method onCreate
// is used.
class srpOnCreateMainActivity extends AppCompatActivity {
   @Override
   protected void onCreate(Bundle savedInstanceState) {
      super.onCreate(savedInstanceState);
      setContentView(R.layout.activity_main);


      // Setting up the button ID
      Button btn_begin = findViewById(R.id.btn_begin);



      // Setting onClickListener to the button so it goes to the "Dashboard Activity"
      btn_begin.setOnClickListener(new View.OnClickListener() {
         @Override
         public void onClick(View v) {
            Intent goToDashboard = new Intent(getApplicationContext(), DashboardNavigation.class);
            startActivity(goToDashboard);
         }
      });


   }
}
