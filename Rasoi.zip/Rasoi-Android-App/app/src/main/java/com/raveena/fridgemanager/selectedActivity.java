package com.raveena.fridgemanager;

import androidx.appcompat.app.AppCompatActivity;

abstract class selectedActivity {
   public AppCompatActivity aboutAct(){
      AboutActivity ac = new AboutActivity();
      return ac;
   }
   public AppCompatActivity contactAct(){
      AboutActivity ac = new AboutActivity();
      return ac;
   }
   public AppCompatActivity helpAct(){
      AboutActivity ac = new AboutActivity();
      return ac;
   }
   public AppCompatActivity settingsAct(){
      AboutActivity ac = new AboutActivity();
      return ac;
   }

}
