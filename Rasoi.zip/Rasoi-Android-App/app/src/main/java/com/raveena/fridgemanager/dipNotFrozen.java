package com.raveena.fridgemanager;

class dipNotFrozen {
}
