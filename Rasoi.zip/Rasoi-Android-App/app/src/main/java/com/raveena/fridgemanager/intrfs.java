package com.raveena.fridgemanager;

import android.os.Bundle;

public interface intrfs {
    public void onCreate(Bundle savedInstanceState);
}
