package com.raveena.fridgemanager;

import android.view.Menu;

import androidx.appcompat.app.AppCompatActivity;
// SOLID bzw. Single Responsability Principle: this class is made from MainActivity.class bzw. the method
// onCreateOptionsMenu is used.
class srpCreateOptionsMenu extends AppCompatActivity {
   @Override
   public boolean onCreateOptionsMenu(Menu menu) {
      getMenuInflater().inflate(R.menu.main_menu, menu);
      return true;
   }

}
