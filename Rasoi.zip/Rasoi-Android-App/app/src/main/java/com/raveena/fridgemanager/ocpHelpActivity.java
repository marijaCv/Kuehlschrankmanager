package com.raveena.fridgemanager;

import android.content.Intent;
import android.view.MenuItem;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
//OPEN CLOSED PRINCIPLE: interface that is the same for each Activity

class ocpHelpActivity extends AppCompatActivity implements ocpOptionsItemSelected{
   @Override
   public void activity(@NonNull MenuItem item) {
      Intent goToActivity;
      if (item.getItemId() == R.id.help) {
         goToActivity = new Intent(getApplicationContext(), HelpActivity.class);
         startActivity(goToActivity);
   }
}
}
