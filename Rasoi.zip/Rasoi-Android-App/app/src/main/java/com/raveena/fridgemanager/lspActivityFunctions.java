package com.raveena.fridgemanager;

abstract class lspActivityFunctions
{
    public abstract void actFunktion();
}
